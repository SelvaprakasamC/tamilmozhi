const express = require("express");
const router = express.Router();

const ctrlUser = require("../controllers/userController");
const ctrlPage = require("../controllers/pages/pageController");
const ctrlCatg = require("../controllers/pages/categoryController");

const jwtHelper = require("../config/jwtHelper");

//User Router
router.post("/register", ctrlUser.register);
router.post("/authenticate", ctrlUser.authenticate);
router.get("/userProfile", jwtHelper.verifyJwtToken, ctrlUser.userProfile);
router.put("/updatePro/:id", ctrlUser.putDetails);
router.get("/user/:id", ctrlUser.getUser);

// Page Router
router.get("/page/", ctrlPage.allData);
router.post("/page/", ctrlPage.addData);
router.get("/page/:id", ctrlPage.idData);
router.put("/page/:id", ctrlPage.putData);
router.delete("/page/:id", ctrlPage.deleteData);
router.post("/page/image_upload", ctrlPage.uploadImage);
router.post("/page/image/", ctrlPage.deleteImage);

// Category Router
router.get("/catg/", ctrlCatg.allData);
router.post("/catg/", ctrlCatg.addData);
router.put("/catg/:id", ctrlCatg.putData);
router.delete("/catg/:id", ctrlCatg.deleteData);

module.exports = router;
