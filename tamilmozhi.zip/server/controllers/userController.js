const mongoose = require("mongoose");
const passport = require("passport");
const _ = require("lodash");
const multer = require("multer");
var path = require("path");
var fs = require("fs");
var ObjectID = require("mongoose").Types.ObjectId;

const User = mongoose.model("User");

const storage = require("../config/helpers/storage");

module.exports.register = (req, res, next) => {
  var filesDir = path.join(
    path.dirname(require.main.filename),
    "public/assets/images/profile/"
  );

  if (!fs.existsSync(filesDir)) {
    fs.mkdirSync(filesDir);
  }
  var user = new User();
  storage(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      return next(err);
    } else if (err) {
      return next(err);
    } else {
      user.fullName = req.body.fullName;
      user.email = req.body.email;
      user.imagePath = req.file.filename;
      user.password = req.body.password;
      user.userName = req.body.userName;

      console.log(req.body);

      user.save((err, doc) => {
        if (!err) {
          res.send(doc);
        } else {
          return next(err);
        }
      });
    }
  });
};

module.exports.authenticate = (req, res, next) => {
  // call for passport authentication
  passport.authenticate("local", (err, user, info) => {
    if (err) {
      // Error from passport middleware
      return res.status(400).json(err);
    } else if (user) {
      // Registered User
      var details = _.pick(user, ["_id", "fullName", "email", "imagePath", "userName"]);
      details.token = user.generateJwt();
      return res.status(200).json(details);
    } else {
      // unknown or wrong password
      return res.status(404).json(info);
    }
  })(req, res);
};

module.exports.userProfile = (req, res, next) => {
  User.findOne({ _id: req._id }, (err, user) => {
    if (!user)
      return res
        .status(404)
        .json({ status: false, message: "User record not found." });
    else
      return res
        .status(200)
        .json({ status: true, user: _.pick(user, ["fullName", "email"]) });
  });
};

module.exports.getUser = (req, res, next) => {
  User.findOne({
    userName: req.params.id
  },
    (err, doc) => {
      // New true is get the doc for updated value
      if (!err && doc != null) {
        var details = _.pick(doc, ["fullName", "email", "userName", "_id", "imagePath"]);
        res.send(details);
      }
      else {
        if (doc != null) {
          res.status(400).send('Data Not Found');
        }
        console.log(
          "Error in Pages Update :" + JSON.stringify(err, undefined, 2)
        );
        return res.status(404).json(JSON.stringify(err, undefined, 2));
      }
    }
  );
}

module.exports.putDetails = (req, res, next) => {
  if (!ObjectID.isValid(req.params.id))
    return res.status(400).send(`No record with given id: ${req.params.id}`);

  storage(req, res, (err) => {
    if (err) {
      return next(err);
    } else {
      var user = {
        fullName: req.body.fullName,
        email: req.body.email,
        userName: req.body.userName
      };

      User.findByIdAndUpdate(
        req.params.id,
        { $set: user },
        { new: true },
        (err, doc) => {
          // New true is get the doc for updated value
          if (!err) {
            var details = _.pick(doc, ["fullName", "email", "userName"]);
            res.send(details);
          }
          else {
            console.log(
              "Error in Pages Update :" + JSON.stringify(err, undefined, 2)
            );
            return res.status(404).json(JSON.stringify(err, undefined, 2));
          }
        }
      );
    }
  });

};
