const express = require("express");
const mongoose = require("mongoose");
var router = express.Router();
const _ = require("lodash");
var ObjectID = require("mongoose").Types.ObjectId;
var path = require("path");
var dateFormat = require("dateformat");
var fs = require("fs");
var FroalaEditor = require("wysiwyg-editor-node-sdk/lib/froalaEditor.js");

var { Page } = require("../../models/pages/page.model");
const User = mongoose.model("User");

// router.get("/", (req, res) => {
module.exports.allData = (req, res) => {
  Page.find((err, docs) => {
    if (!err) {
      res.send(docs);
    } else {
      console.log(
        "Error in Retriving Pages :" + JSON.stringify(err, undefined, 2)
      );
    }
  });
};

// Data Get Method

// router.get("/:id", (req, res) => {
module.exports.idData = (req, res) => {
  if (!ObjectID.isValid(req.params.id))
    return res.status(400).send(`No record with given id: ${req.params.id}`);

  // get Blog Details
  Page.findById(req.params.id, (err, doc) => {
    if (!err) {
      const aID = doc.author;
      if (!ObjectID.isValid(aID))
        return res.status(400).send(`No record with given user id: ${req.params.id}`);

      // get Author Details
      User.findById(aID, (uerr, udoc) => {
        if (!uerr) {
          doc.author = _.omit(udoc, ["_id", "fullName", "email", "imagePath", "userName"]);
          res.send(doc);
        } else {
          console.log("Error in Pages Get :" + JSON.stringify(uerr, undefined, 2));
        }
      });
    } else {
      console.log("Error in Pages Get :" + JSON.stringify(err, undefined, 2));
    }
  });
};

// Data Post method

// router.post("/", (req, res) => {
module.exports.addData = (req, res) => {
  var page = new Page({
    title: req.body.title,
    content: req.body.content,
    category: req.body.category,
    url: req.body.url,
    author: req.body.author,
    status: req.body.status,
    date: dateFormat(new Date(), "dddd, mmm dS, yyyy, h:MM:ss TT")
  });
  console.log(page);
  page.save((err, doc) => {
    if (!err) {
      res.send(doc);
    } else {
      console.log("Error in Pages Save :" + JSON.stringify(err, undefined, 2));
    }
  });
};

// router.put("/:id", (req, res) => {
module.exports.putData = (req, res) => {
  if (!ObjectID.isValid(req.params.id))
    return res.status(400).send(`No record with given id: ${req.params.id}`);

  var page = {
    title: req.body.title,
    content: req.body.content,
    category: req.body.category,
    url: req.body.url,
    author: req.body.author,
    status: req.body.status,
    date: dateFormat(new Date(), "dddd, mmm dS, yyyy, h:MM:ss TT")
  };
  console.log(page)
  Page.findByIdAndUpdate(
    req.params.id,
    { $set: page },
    { new: true },
    (err, doc) => {
      // New true is get the doc for updated value
      if (!err) res.send(doc);
      else {
        console.log(
          "Error in Pages Update :" + JSON.stringify(err, undefined, 2)
        );
      }
    }
  );
};

// router.delete("/:id", (req, res) => {
module.exports.deleteData = (req, res) => {
  if (!ObjectID.isValid(req.params.id))
    return res.status(400).send(`No record with given id: ${req.params.id}`);

  Page.findByIdAndRemove(req.params.id, (err, doc) => {
    if (!err) res.send(doc);
    else {
      console.log(
        "Error in Pages Delete :" + JSON.stringify(err, undefined, 2)
      );
    }
  });
};

// Image POST handler.
// app.post("/image_upload", function(req, res) {
module.exports.uploadImage = (req, res) => {
  var filesDir = path.join(
    path.dirname(require.main.filename),
    "public/assets/images/"
  );

  if (!fs.existsSync(filesDir)) {
    fs.mkdirSync(filesDir);
  }
  // Create folder for uploading files.
  FroalaEditor.Image.upload(
    req,
    "/public/assets/images/",
    function (err, data) {
      if (err) {
        return res.send(JSON.stringify(err));
      }
      var s = data.link.split("/");
      var li = `/${s[2]}/${s[3]}/${s[4]}`;
      data.link = li;
      console.log(data.link);
      res.send(data);
    }
  );
};

module.exports.deleteImage = (req, res) => {
  var s = req.body.url.split("/");

  var li = `/${s[3]}/${s[4]}/${s[5]}`;
  console.log(li);
  fs.unlink(`public${li}`, (err, doc) => {
    if (err) {
      console.log(
        "Error in Pages Delete :" + JSON.stringify(err, undefined, 2)
      );
    } else {
      res.send(doc);
    }
  });
};

// module.exports = router;
