const express = require("express");
var router = express.Router();
var ObjectID = require("mongoose").Types.ObjectId;

var { Category } = require("../../models/pages/category.model");

module.exports.allData = (req, res) => {
  Category.find((err, docs) => {
    if (!err) {
      res.send(docs);
    } else {
      console.log(
        "Error in Retriving Pages :" + JSON.stringify(err, undefined, 2)
      );
    }
  });
};

module.exports.addData = (req, res) => {
  var category = new Category({
    name: req.body.name,
    description: req.body.description,
    type: req.body.type,
    parent: req.body.parent,
    slug: req.body.slug,
    author: req.body.author,
    mainParent: req.body.mainParent,
    subParent: req.body.subParent,
    supParent: req.body.supParent
  });
  if (req.body.type === 1) {
    if (req.body.mainParent) {
      Category.findById(req.body.mainParent, (err, doc) => {
        if (!err) {
          if (req.body.subParent && req.body.subParent != 0) {
            doc.subCategory.find(c => {
              if (c._id == req.body.subParent) {
                if (req.body.supParent && req.body.supParent != 0) {
                  c.subCategory.find(a => {
                    if (a._id == req.body.supParent) {
                      a.subCategory.push(category);
                    }
                  });
                } else {
                  c.subCategory.push(category);
                }
              }
            });
          } else {
            doc.subCategory.push(category);
          }
          doc.save((err, doc) => {
            if (!err) {
              res.send(doc);
            } else {
              console.log(
                "Error in Pages Save :" + JSON.stringify(err, undefined, 2)
              );
            }
          });
        } else {
          console.log(
            "Error in Pages Save :" + JSON.stringify(err, undefined, 2)
          );
        }
      });
    }
  } else {
    category.save((err, doc) => {
      if (!err) {
        res.send(doc);
      } else {
        console.log(
          "Error in Pages Save :" + JSON.stringify(err, undefined, 2)
        );
      }
    });
  }
};

module.exports.putData = (req, res) => {
  if (!ObjectID.isValid(req.params.id))
    return res.status(400).send(`No record with given id: ${req.params.id}`);

  var category = {
    name: req.body.name,
    description: req.body.description,
    mainParent: req.body.mainParent,
    subParent: req.body.subParent,
    supParent: req.body.supParent,
    type: req.body.type,
    slug: req.body.slug,
    author: req.body.author
  };

  if (req.body.type === 1 && req.body.mainParent != 0) {
    if (req.body.subParent && req.body.subParent != 0) {
      if (req.body.supParent && req.body.supParent != 0) {
        Category.updateOne(
          {
            _id: req.body.mainParent,
            "subCategory._id": req.body.subParent,
            "subCategory.subCategory._id": req.body.supParent,
            "subCategory.subCategory.subCategory._id": req.body._id
          },
          {
            $set: {
              "subCategory.$.subCategory.0.subCategory.0.name": req.body.name,
              "subCategory.$.subCategory.0.subCategory.0.description":
                req.body.description,
              "subCategory.$.subCategory.0.subCategory.0.slug": req.body.slug
            }
          },
          (err, doc) => {
            if (!err) res.send(doc);
            else {
              console.log(
                "Error in Pages Update :" + JSON.stringify(err, undefined, 2)
              );
            }
          }
        );
      } else {
        Category.updateOne(
          {
            _id: req.body.mainParent,
            "subCategory._id": req.body.subParent,
            "subCategory.subCategory._id": req.body._id
          },
          {
            $set: {
              "subCategory.$.subCategory.0.name": req.body.name,
              "subCategory.$.subCategory.0.description": req.body.description,
              "subCategory.$.subCategory.0.slug": req.body.slug
            }
          },
          (err, doc) => {
            if (!err) res.send(doc);
            else {
              console.log(
                "Error in Pages Update :" + JSON.stringify(err, undefined, 2)
              );
            }
          }
        );
      }
    } else {
      Category.updateOne(
        { _id: req.body.mainParent, "subCategory._id": req.body._id },
        {
          $set: {
            "subCategory.$.name": req.body.name,
            "subCategory.$.description": req.body.description,
            "subCategory.$.slug": req.body.slug
          }
        },
        { new: true },
        (err, doc) => {
          console.log(err);
          if (!err) res.send(doc);
          else {
            console.log(
              "Error in Pages Update :" + JSON.stringify(err, undefined, 2)
            );
          }
        }
      );
    }
  } else if (req.body.type === 0) {
    Category.findByIdAndUpdate(
      req.params.id,
      { $set: category },
      { new: true },
      (err, doc) => {
        console.log(err);
        if (!err) res.send(doc);
        else {
          console.log(
            "Error in Pages Update :" + JSON.stringify(err, undefined, 2)
          );
        }
      }
    );
  }
};

module.exports.deleteData = (req, res) => {
  const id = req.params.id.split("+");

  if (id[1]) {
    if (!ObjectID.isValid(id[1]))
      return res.status(400).send(`No record with given id: ${id[1]}`);

    if (id[2]) {
      if (id[3]) {
        Category.updateOne(
          {
            _id: id[0],
            "subCategory._id": id[1],
            "subCategory.subCategory._id": id[2]
          },
          {
            $pull: { "subCategory.$.subCategory.0.subCategory": { _id: id[3] } }
          },
          (err, doc) => {
            if ((err, doc)) {
              "Error in Pages Delete :" + JSON.stringify(err, undefined, 2);
            } else {
              return res.send(doc);
            }
          }
        );
      } else {
        Category.updateOne(
          { _id: id[0], "subCategory._id": id[1] },
          { $pull: { "subCategory.$.subCategory": { _id: id[2] } } },
          (err, doc) => {
            if (err) {
              "Error in Pages Delete :" + JSON.stringify(err, undefined, 2);
            } else {
              return res.send(doc);
            }
          }
        );
      }
    } else {
      console.log("sub");
      Category.updateOne(
        { _id: id[0] },
        { $pull: { subCategory: { _id: id[1] } } },
        (err, doc) => {
          if (err) {
            "Error in Pages Delete :" + JSON.stringify(err, undefined, 2);
          } else {
            return res.send(doc);
          }
        }
      );
    }
  } else {
    if (!ObjectID.isValid(req.params.id))
      return res.status(400).send(`No record with given id: ${req.params.id}`);

    Category.findByIdAndRemove(req.params.id, (err, doc) => {
      if (!err) res.send(doc);
      else {
        console.log(
          "Error in Pages Delete :" + JSON.stringify(err, undefined, 2)
        );
      }
    });
  }
};
