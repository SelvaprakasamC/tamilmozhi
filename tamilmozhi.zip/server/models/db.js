const mongoose = require("mongoose");
mongoose.set("useCreateIndex", true);

// mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true }, err => {
mongoose.connect(
  process.env.MONGODB_URI,
  { useNewUrlParser: true, useUnifiedTopology: true },
  err => {
    if (!err) console.log("MongoDB Connected Successfully.");
    else
      console.log(
        "eRROR IN db CONNECTION :" + JSON.stringify(err, undefined, 2)
      );
  }
);

// module.exports = mongoose;

require("../models/user.model");
