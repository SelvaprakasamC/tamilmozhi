const mongoose = require("mongoose");

var Page = mongoose.model("Page", {
  title: { type: String },
  content: { type: String },
  category: { type: String },
  url: {
    type: String,
    required: "Email can't be empty",
    unique: true,
  },
  author: { type: Object },
  status: { type: Number },
  date: { type: String }
});

module.exports = { Page };
