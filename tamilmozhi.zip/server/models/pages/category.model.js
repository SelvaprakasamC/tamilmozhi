const mongoose = require("mongoose");
var Schema = mongoose.Schema;

var CategorySchema = new Schema();

CategorySchema.add({
  name: String,
  description: String,
  slug: {
    type: String,
    required: "Email can't be empty",
    unique: true,
  },
  type: Number,
  mainParent: String,
  subParent: String,
  supParent: String,
  author: Object,
  subCategory: [CategorySchema],
});

const Category = mongoose.model("Category", CategorySchema);

module.exports = { Category };
