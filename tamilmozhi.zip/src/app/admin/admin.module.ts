import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AngularMaterialModule } from '../theme/angular-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FroalaEditorModule } from 'angular-froala-wysiwyg';
import 'froala-editor/js/plugins.pkgd.min.js';

import { AdminRoutingModule } from './admin-routing.module';
import { AHeaderComponent } from './a-header/a-header.component';
import { AFooterComponent } from './a-footer/a-footer.component';
import { AdminComponent } from './admin.component';
import { ASidenavComponent } from './a-sidenav/a-sidenav.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { APagesComponent } from './pages/a-pages/a-pages.component';
import { PageListComponent } from './pages/a-pages/page-list/page-list.component';
import { NewPageComponent } from './pages/a-pages/new-page/new-page.component';
import { ACategoryComponent } from './pages/a-category/a-category.component';
import { ProfileComponent } from './a-header/profile/profile.component';




const MODULES = [
  AdminRoutingModule,
  AngularMaterialModule,
  FormsModule,
  FroalaEditorModule,
  ReactiveFormsModule,
];

const COMPONENTS = [
  AHeaderComponent,
  AFooterComponent,
  AdminComponent,
  DashboardComponent,
  ASidenavComponent,
  APagesComponent,
  PageListComponent,
  NewPageComponent,
  ACategoryComponent
];

@NgModule({
  declarations: [...COMPONENTS, ProfileComponent],
  imports: [CommonModule, ...MODULES],
  exports: [CommonModule, ...COMPONENTS],
  providers: [],
})
export class AdminModule { }
