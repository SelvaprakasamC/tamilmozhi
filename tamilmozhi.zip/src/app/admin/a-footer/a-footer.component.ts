import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-a-footer',
  templateUrl: './a-footer.component.html',
  styleUrls: ['./a-footer.component.scss']
})
export class AFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
