import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { APagesComponent } from './pages/a-pages/a-pages.component';
import { PageListComponent } from './pages/a-pages/page-list/page-list.component';
import { NewPageComponent } from './pages/a-pages/new-page/new-page.component';
import { ACategoryComponent } from './pages/a-category/a-category.component';
import { ProfileComponent } from './a-header/profile/profile.component';


const routes: Routes = [
  {
    path: '', component: AdminComponent,
    children: [
      { path: '', redirectTo: 'home', pathMatch: 'full' },
      { path: 'home', component: DashboardComponent, pathMatch: 'full' },
      {
        path: 'profile', component: ProfileComponent, pathMatch: 'full'
      },
      {
        path: 'pages', component: APagesComponent,
        children: [
          { path: '', component: PageListComponent, pathMatch: 'full' },
          { path: 'addnew', component: NewPageComponent },
          { path: 'update/:id', component: NewPageComponent },
        ]
      },
      { path: 'category', component: ACategoryComponent, pathMatch: 'full' },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class AdminRoutingModule { }
