import { Component, OnInit } from '@angular/core';
import { FormGroup, NgForm } from '@angular/forms';
import { User } from 'src/app/@core/models/user/user.model';
import { UserService } from 'src/app/@core/services/user/user.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
  imageUrl: any;
  value;
  imageData: any;
  hide = true;
  message: boolean;
  user: User;
  profileForm: FormGroup;
  constructor(
    private userService: UserService,
    private _snackBar: MatSnackBar) { }

  ngOnInit() {
    this.user = this.userService.userDetails;
  }
  onFileSelect(event: Event) {
    const file = (event.target as HTMLInputElement).files[0];
    if (file.size < 512000) {
      this.imageData = file;
      const allowedMimeTypes = ["image/png", "image/jpeg", "image/jpg"];
      if (file && allowedMimeTypes.includes(file.type)) {
        const reader = new FileReader();
        reader.onload = () => {
          this.imageUrl = reader.result as string;
        };
        reader.readAsDataURL(file);
      }
    } else {
      this._snackBar.open('File Size Max allowed 512kb', "okay", { duration: 4000 });
    }
  }

  update(form: NgForm) {
    this.userService.updateUserProfile(form.value, this.imageData).subscribe(
      res => {
        let data;
        this.userService.userDetails = Object.assign({}, this.userService.userDetails, res);
        if (localStorage.getItem('TamilMozhiUser') != null) {
          data = Object.assign({}, JSON.parse(localStorage.TamilMozhiUser), res);
          localStorage.setItem('TamilMozhiUser', JSON.stringify(data));
        } else {
          data = Object.assign({}, JSON.parse(sessionStorage.TamilMozhiUser), res);
          sessionStorage.setItem('TamilMozhiUser', JSON.stringify(data));
        }
        this._snackBar.open('Updated Successfully!!', 'Okay', { duration: 3000 })
      },
      err => {
        const e = JSON.parse(err.error);
        if (e.code == 11000) {
          this._snackBar.open(`'${e.keyValue[Object.keys(e.keyValue)[0]]}' already Exist`, 'Okay', { duration: 3000 })
        } else {
          this._snackBar.open('Something Went Wong!!', 'Okay', { duration: 3000 })
        }
      })
  }
}
