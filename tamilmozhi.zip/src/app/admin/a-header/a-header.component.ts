import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/@core/services/user/user.service';
import { Router } from '@angular/router';
import { User } from 'src/app/@core/models/user/user.model';

@Component({
  selector: 'app-a-header',
  templateUrl: './a-header.component.html',
  styleUrls: ['./a-header.component.scss']
})
export class AHeaderComponent implements OnInit {
  user: User;

  constructor(private userService: UserService, private router: Router) { }

  ngOnInit() {
    this.user = this.userService.userDetails;
  }

  toggleSideNav() {
    const sNav = document.querySelector<HTMLInputElement>('#sideNav');

    if (sNav.clientWidth === 55) {
      sNav.style.width = '250px';
    } else {
      sNav.style.width = '55px';
    }
  }

  onLogout() {
    this.userService.deleteToken();
    this.router.navigate(['/user']);
  }
}
