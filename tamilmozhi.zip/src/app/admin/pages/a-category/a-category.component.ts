import { Component, OnInit } from '@angular/core';
import { NestedTreeControl } from '@angular/cdk/tree';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { NgForm } from '@angular/forms';
import { Category } from 'src/app/@core/models/pages/category.model';
import { CategoryService } from 'src/app/@core/services/pages/category.service';
import { UserService } from 'src/app/@core/services/user/user.service';

@Component({
  selector: 'app-a-category',
  templateUrl: './a-category.component.html',
  styleUrls: ['./a-category.component.scss']
})
export class ACategoryComponent implements OnInit {
  // Mat tree
  treeControl = new NestedTreeControl<Category>(node => node.subCategory);
  dataSource = new MatTreeNestedDataSource<Category>();

  category: Category;
  user;
  MainParent;
  SubParent = 0;
  SupParent = 0;
  allCategory;
  MainParentList;
  SubParentList: any = [];
  SupParentList: Category[] = [];

  allCategoryObj: any = [];

  constructor(
    private catgService: CategoryService,
    private userService: UserService
  ) {
  }

  ngOnInit() {

    this.user = this.userService.userDetails;
    this.resetForm();
    this.getCayegory();

  }
  // Mat tree
  hasChild = (_: number, node: Category) => !!node.subCategory && node.subCategory.length > 0;

  resetForm(form?: NgForm) {
    if (form) { form.reset(); }
    this.category = {
      _id: null,
      name: '',
      slug: '',
      description: '',
      type: 0,
      author: '',
      subCategory: null,
    };
    this.SubParentList = [];
    this.SupParentList = [];
    this.MainParent = '';
  }

  getCayegory() {
    this.catgService.getCategory().subscribe((res) => {
      this.allCategory = res;
      this.dataSource.data = this.allCategory;
      if (Array.isArray(res)) {
        return this.MainParentList = res.filter(c => c.type === 0);
      }
    });

  }

  onSubmit(form: NgForm) {
    form.value.author = this.user;
    if (!form.value._id) {
      this.catgService.addCategory(form.value).subscribe((res) => {
      });
      this.resetForm();
    } else {
      if (form.value.type !== 0) {
        if (this.MainParent !== null) {
          form.value.mainParent = this.MainParent;
          if (this.SubParent !== null) {
            form.value.subParent = this.SubParent;
            if (this.SupParent !== null) {
              form.value.supParent = this.SupParent;
            }
          }
        }
      }
      this.catgService.updateCategory(form.value).subscribe((res) => {
      });
    }

    this.getCayegory();

  }

  onEdit(catg) {
    this.category = {
      _id: catg._id,
      name: catg.name,
      slug: catg.slug,
      description: catg.description,
      type: catg.type,
      author: '',
    };
    if (catg.type === 1) {
      this.SupParentList = [];
      this.SubParentList = [];
      this.MainParent = this.SupParent = this.SubParent = null;
      this.allCategory.filter(m => {
        if (m._id === catg.mainParent) {
          this.MainParent = catg.mainParent;
          if (catg.subParent && catg.subParent != 0) {
            this.subParentCheck(catg.mainParent, 'sub');
            this.SubParent = catg.subParent;
            console.log(this.SubParentList);
            if (catg.supParent && catg.supParent != 0) {
              this.subParentCheck(catg.subParent, 'sup');
              this.SupParent = catg.supParent;
            }
          }
        }
      });
    } else { return; }
  }

  onDelete(catg) {
    let id;
    if (catg.type === 1 && catg.mainParent && catg.mainParent != 0) {
      if (catg.subParent && catg.subParent != 0) {
        if (catg.supParent && catg.supParent != 0) {
          id = catg.mainParent + '+' + catg.subParent + '+' + catg.supParent + '+' + catg._id;
        } else {
          id = catg.mainParent + '+' + catg.subParent + '+' + catg._id;
        }
      } else {
        id = catg.mainParent + '+' + catg._id;
      }
    } else if (catg.type === 0) {
      id = catg._id;
    } else { return; }


    if (confirm('Are you sure to delete this record ?') === true) {
      this.catgService.deleteCategory(id).subscribe((res) => {
        this.getCayegory();
        // M.toast({ html: 'Deleted Successfully', class: 'rounded' });
      }, (err) => { console.log(err); });

    }
  }

  subParentCheck(id, node?: string) {
    if (node === 'sub') {
      this.SupParentList = [];
      this.SubParentList = [];
      this.allCategory.filter(c => {
        if (c._id === id) {
          return this.SubParentList = c.subCategory;
        }
      });
    } else if (node === 'sup') {
      this.SupParentList = [];
      this.SubParentList.filter(c => {
        if (c._id === id) {
          return this.SupParentList = c.subCategory;
        }
      });
    }

  }

}
