import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { SelectionModel } from '@angular/cdk/collections';
import { Page } from 'src/app/@core/models/pages/page.model';
import { PageService } from 'src/app/@core/services/pages/page.service';
import { Router } from '@angular/router';
import { CategoryService } from 'src/app/@core/services/pages/category.service';
import { Category } from 'src/app/@core/models/pages/category.model';

@Component({
  selector: 'app-page-list',
  templateUrl: './page-list.component.html',
  styleUrls: ['./page-list.component.scss']
})
export class PageListComponent implements OnInit {
  value;
  allCatg;

  displayedColumns: string[] = ['select', 'title', 'category', 'author', 'status', 'action'];
  dataSource = new MatTableDataSource<Page>();
  selection = new SelectionModel<Page>(true, []);

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    private router: Router,
    private catgService: CategoryService,
    private pageService: PageService) { }

  ngOnInit() {
    this.getCategory();
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.refreshPages();
  }

  refreshPages() {
    this.pageService.getPages().subscribe((res: Array<Page>) => {
      for (const item of res) {
        item.category = this.changeCatgName(item.category);
      }
      return this.dataSource.data = res as Page[];
    });
  }

  getCategory() {
    this.catgService.getCategory().subscribe((res) => {
      return this.allCatg = res as Category;
    });
  }

  changeCatgName(i) {
    if (i !== '' && i !== null && i !== undefined) {
      const s = i.split('/');
      const main = this.allCatg.find((e) => e.slug === s[0]);
      if (s[1]) {
        const sub = main.subCategory.find((e) => e.slug === s[1]);
        if (s[2]) {
          const sup = sub.subCategory.find((e) => e.slug === s[2]);
          return main.name + ' > ' + sub.name + ' > ' + sup.name;
        }
        return main.name + ' > ' + sub.name;
      }
      return main.name;
    } else {
      return 'No Category';
    }
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: Page): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row._id + 1}`;
  }

  onEdit(page: Page) {
    this.router.navigate(['/admin/pages/update', page._id]);
  }

  onDelete(id: string) {
    if (confirm('Are you sure to delete this record ?') === true) {
      this.pageService.deletePage(id).subscribe((res) => {
        this.refreshPages();
        // M.toast({ html: 'Deleted Successfully', class: 'rounded' });
      }, (err) => { console.log(err); });
    }
  }
}
