import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-a-pages',
  templateUrl: './a-pages.component.html',
  styleUrls: ['./a-pages.component.scss']
})
export class APagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
