import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Form, FormControl, NgForm } from '@angular/forms';
import { PageService } from 'src/app/@core/services/pages/page.service';
import { Page } from 'src/app/@core/models/pages/page.model';
import { UserService } from 'src/app/@core/services/user/user.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CategoryService } from 'src/app/@core/services/pages/category.service';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-new-page',
  templateUrl: './new-page.component.html',
  styleUrls: ['./new-page.component.scss']
})
export class NewPageComponent implements OnInit {
  editorData;
  user;
  categoryList;
  categoryMain;
  categorySub;
  categorySup;
  saveMsg: string;
  categorySubList = [];
  categorySupList = [];
  readonly baseURL = environment.apiBaseUrl + '/page/';

  @ViewChild('pageForm', { static: false }) form: NgForm;

  toppings = new FormControl();
  page: Page;
  public options: object;

  toppingList: string[] = ['Extra cheese', 'Mushroom', 'Onion', 'Pepperoni', 'Sausage', 'Tomato'];

  constructor(
    private userService: UserService,
    private pageService: PageService,
    private catgService: CategoryService,
    private route: ActivatedRoute,
    private router: Router) {

  }

  ngOnInit() {
    this.user = this.userService.userDetails;
    this.getCategory();
    this.route.params.subscribe(params => {
      this.resetForm();
      if (params['id']) {
        this.getSelecedPage(params['id']);
      }
    });
    let _this = this;
    this.options = {
      charCounterCount: true,
      attribution: false,
      imageUploadURL: this.baseURL + 'image_upload',
      imageUploadParams: { id: 'cntEditor' },

      events: {
        'image.removed'($img) {
          _this.deleteImage($img);
        },
        'contentChanged'() {
          _this.onChange();
        }
      }
    };
  }

  // Reset Form
  resetForm(form?: NgForm) {
    if (form) { form.reset(); }
    this.page = {
      _id: '',
      title: '',
      url: '',
      content: '',
      category: '',
      author: '',
      status: null
    };
    this.categoryMain = 0;
    this.categorySub = 0;
    this.categorySup = 0;
  }

  // On submit Form
  onSubmit(form, sts: Number = 0) {
    this.saveMsg = "Draft Saving..."
    form.value.status = sts;
    form.value.author = this.user._id;
    form.value.category = this.joinCategory();

    console.log(form.value);
    if (form.value._id === '') {
      this.pageService.addPage(form.value).subscribe((res) => {
        this.saveMsg = "Draft Saved!"
        // M.toast({ html: 'Saved Successfully', class: 'rounded' });
      });
    } else {
      this.pageService.updatePage(form.value).subscribe((res) => {
        this.saveMsg = "Draft Saved!"
        // M.toast({ html: 'Updated Successfully', class: 'rounded' });
      });
    }

    if (sts === 1) {
      this.resetForm();
      this.router.navigate(['/admin/pages']);
    }

  }



  joinCategory() {
    if (this.categoryMain !== 0) {
      if (this.categorySub !== 0) {
        if (this.categorySup !== 0) {
          return this.categoryMain + '/' + this.categorySub + '/' + this.categorySup;
        } else {
          return this.categoryMain + '/' + this.categorySub;
        }
      } else {
        return this.categoryMain;
      }
    } else {
      return null;
    }
  }

  getSelecedPage(id) {
    this.pageService.getPages().subscribe((res) => {
      if (Array.isArray(res)) {
        setTimeout(() => {
          this.page = res.filter(page => page._id === id)[0] as Page;
          if (this.page.category != '0') {
            const split = this.page.category.split('/');
            if (split.length > 0) {
              this.categoryMain = split[0];
              if (split.length > 1) {
                this.catgSelect('sub');
                this.categorySub = split[1];
                if (split.length > 2) {
                  this.catgSelect('sup');
                  this.categorySup = split[2];
                }
              }
            }
          }
        });

      }
    });
  }

  getCategory() {
    this.catgService.getCategory().subscribe((res) => {
      this.categoryList = res;
    });
  }

  catgSelect(node) {
    if (node === 'sub') {
      this.categorySubList = [];
      this.categorySupList = [];
      this.categorySub = 0;
      this.categoryList.filter(c => {
        if (c.slug === this.categoryMain) {
          return this.categorySubList = c.subCategory;
        }
      });
    } else if (node === 'sup') {
      this.categorySupList = [];
      this.categorySup = 0;
      this.categorySubList.filter(c => {
        if (c.slug === this.categorySub) {
          return this.categorySupList = c.subCategory;
        }
      });
    } else {
      return;
    }
  }
  urlUpdate(e: any) {
    this.page.url = e.target.value.replace(/\s+/g, '-').toLowerCase();
  }

  onEdit(page: Page) {
    this.pageService.selectPage = page;
  }

  onDelete(id: string, form: NgForm) {
    if (confirm('Are you sure to delete this record ?') === true) {
      this.pageService.deletePage(id).subscribe((res) => {
        // M.toast({ html: 'Deleted Successfully', class: 'rounded' });
      }, (err) => { console.log(err); });
    }
  }

  deleteImage(img) {
    const image: any = {};
    image.url = img[0].src;
    console.log(image);
    this.pageService.deleteimege(image).subscribe(() => {
    });
  }

  onChange() {
    this.saveMsg = "";
    setTimeout(() => {
      console.log(this.form.form.value)
      this.onSubmit(this.form.form, 0)
    }, 3000);
  }
}
