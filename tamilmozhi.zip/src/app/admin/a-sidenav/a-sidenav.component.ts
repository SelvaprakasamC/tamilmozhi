import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-a-sidenav',
  templateUrl: './a-sidenav.component.html',
  styleUrls: ['./a-sidenav.component.scss']
})
export class ASidenavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
