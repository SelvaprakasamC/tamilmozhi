import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { ThemeModule } from './theme/theme.module';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';


import 'hammerjs';
import { UserComponent } from './user/user.component';
import { LoginComponent } from './user/login/login.component';
import { SignupComponent } from './user/signup/signup.component';
import { AngularMaterialModule } from './theme/angular-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UserService } from './@core/services/user/user.service';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthGuard } from './@core/security/auth/auth.guard';
import { AuthInterceptor } from './@core/security/auth/auth.interceptor';
import { PageService } from './@core/services/pages/page.service';
import { CategoryService } from './@core/services/pages/category.service';
import { PagenotfoundComponent } from './theme/layout/pagenotfound/pagenotfound.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    LoginComponent,
    SignupComponent,
    PagenotfoundComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AngularMaterialModule,
    AppRoutingModule,
    ThemeModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgbModule

    // ThemeModule,
    // ViewModule,
    // AdminModule,
    // AngularMaterialModule,
  ],
  providers: [UserService, PageService, CategoryService, AuthGuard, { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }],
  bootstrap: [AppComponent]
})
export class AppModule { }
