import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewComponent } from './view.component';
import { HomeComponent } from './home/home.component';
import { PagesComponent } from './pages/pages.component';
import { PagenotfoundComponent } from '../theme/layout/pagenotfound/pagenotfound.component';
import { AuthorComponent } from './author/author.component';


const routes: Routes = [
  {
    path: '', component: ViewComponent,
    children: [
      { path: '', component: HomeComponent, pathMatch: 'full' },
      { path: 'blog/:id', component: PagesComponent },
      { path: ':id', component: AuthorComponent }
    ]
  }
  // { path: '**', component: PagenotfoundComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class ViewRoutingModule { }
