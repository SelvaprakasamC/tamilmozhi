import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from 'src/app/@core/models/user/user.model';
import { UserService } from 'src/app/@core/services/user/user.service';

@Component({
  selector: 'app-author',
  templateUrl: './author.component.html',
  styleUrls: ['./author.component.scss']
})
export class AuthorComponent implements OnInit {
  user: User;

  constructor(private userService: UserService, private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.getDetails(params['id']);
      }
    });
  }

  getDetails(uName) {
    this.userService.getUser(uName).subscribe(res => {
      this.user = res as User;
    }, err => {
      if (err.error === "null") {
        this.router.navigate(['']);
      }
      console.log(err)
    })
  }

}
