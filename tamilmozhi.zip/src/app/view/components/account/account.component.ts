import { Component, OnInit, Inject } from '@angular/core';
import { NgForm } from '@angular/forms';
import { VERSION, MatDialogRef, MatDialog, MatSnackBar, MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router';
import { UserService } from 'src/app/@core/services/user/user.service';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.scss']
})
export class AccountComponent implements OnInit {
  login = 0;
  remember = true;
  hide = true;
  fLogin = {
    email: '',
    password: ''
  };

  constructor(@Inject(MAT_DIALOG_DATA) private data: any,
    private dialogRef: MatDialogRef<AccountComponent>,
    private userService: UserService,
    private router: Router) {
    if (data) {
      this.login = data.type || this.login;
    }
  }

  ngOnInit() {
  }

}
