import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/@core/services/user/user.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialogRef } from '@angular/material';
import { AccountComponent } from '../account.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  value;
  remember = true;
  hide = true;
  model = {
    email: '',
    password: ''
  };
  serverErrorMessages;
  constructor(
    private userService: UserService,
    private router: Router,
    private _snackBar: MatSnackBar,
    private dialogRef: MatDialogRef<AccountComponent>
  ) { }

  ngOnInit() {
    if (this.userService.isLoggedIn()) {
      this.router.navigate(['/admin']);
    }
  }

  onSubmit(form: NgForm) {
    this.userService.login(form.value).subscribe(
      res => {
        this.userService.setToken(JSON.stringify(res), this.remember);
        this._snackBar.open('Login Successfully!!', 'Okay', { duration: 3000 });
        console.log(this.userService.userDetails);
        this.userService.isLoggedIn();
        console.log(this.userService.userDetails);
        this.dialogRef.close(true);
      },
      err => {
        this.serverErrorMessages = err.error.message;
        this._snackBar.open(err.error.message, 'Okay', { duration: 5000 })
      }
    );
  }

}
