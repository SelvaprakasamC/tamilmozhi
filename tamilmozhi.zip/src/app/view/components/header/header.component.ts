import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/@core/models/user/user.model';
import { UserService } from 'src/app/@core/services/user/user.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AccountComponent } from '../account/account.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  inputSearch;
  user;
  constructor(private userService: UserService, private dialog: MatDialog) { }

  ngOnInit() {
    this.userService.isLoggedIn();
    this.user = this.userService.userDetails;
    this.userService.user$.subscribe(user => this.user = user);
  }
  filterSearch() {

  }

  openAccount(t) {
    var account = this.dialog.open(AccountComponent, {
      data: {
        type: t,
      },
      maxWidth: 430,
      autoFocus: true,
    });
  }

  signOut() {
    this.userService.deleteToken();
    // location.reload();
  }
}
