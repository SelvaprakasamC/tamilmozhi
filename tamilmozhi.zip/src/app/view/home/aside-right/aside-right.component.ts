import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aside-right',
  templateUrl: './aside-right.component.html',
  styleUrls: ['./aside-right.component.scss']
})
export class AsideRightComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
