import { Component, OnInit } from '@angular/core';
import { filter, map, take } from 'rxjs/operators';
import { Page } from 'src/app/@core/models/pages/page.model';
import { PageService } from 'src/app/@core/services/pages/page.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  latest;
  constructor(private pageService: PageService) { }

  ngOnInit() {
    this.getLatest();
  }

  getLatest() {
    this.pageService.getPages().pipe(
      take(10)
    ).subscribe((res: Array<Page>) => {
      this.latest = res.filter(a => a.status === 1) as Page[];
      console.log(this.latest);
    });
  }
  btoa(id) {
    return btoa(id);
  }
}
