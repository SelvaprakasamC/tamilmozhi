import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule } from '@angular/forms';

import { FroalaViewModule } from 'angular-froala-wysiwyg';

import { HomeComponent } from './home/home.component';
import { ViewRoutingModule } from './view-routing.module';
import { ViewComponent } from './view.component';
import { PagesComponent } from './pages/pages.component';
import { BlogComponent } from './pages/blog/blog.component';
import { SideNavComponent } from './pages/side-nav/side-nav.component';
import { AngularMaterialModule } from '../theme/angular-material.module';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { LoaderComponent } from './components/loader/loader.component';
import { AsideRightComponent } from './home/aside-right/aside-right.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AuthorComponent } from './author/author.component';
import { AccountComponent } from './components/account/account.component';
import { LoginComponent } from './components/account/login/login.component';
import { SignupComponent } from './components/account/signup/signup.component';




const MODULES = [
  ViewRoutingModule,
  FroalaViewModule,
  AngularMaterialModule,
  FormsModule,
  NgbModule
];

const COMPONENTS = [
  ViewComponent,
  HomeComponent,
  PagesComponent,
  BlogComponent
];

@NgModule({
  declarations: [...COMPONENTS, SideNavComponent, HeaderComponent, FooterComponent, LoaderComponent, AsideRightComponent, AuthorComponent, AccountComponent, LoginComponent, SignupComponent],
  imports: [CommonModule, ...MODULES],
  exports: [CommonModule, ...COMPONENTS],
})

export class ViewModule { }
