import { Component, HostListener, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PageService } from 'src/app/@core/services/pages/page.service';
import { Page } from 'src/app/@core/models/pages/page.model';
import FroalaEditor from 'froala-editor';
import { filter, map } from 'rxjs/operators';

@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.scss']
})
export class BlogComponent implements OnInit {
  blog: Page;
  blogUrl;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private pageService: PageService
  ) {
  }

  ngOnInit() {
    // Router get parameter ID
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.getBlog(params['id']);
      }
    });
  }

  // get Blog
  getBlog(url) {
    const eID = url.split('-').pop();
    const id = atob(eID);
    this.pageService.getPage(id).subscribe(res => {
      this.blog = res as Page;
      const rURL = `${this.blog.url}-${eID}`;
      if (url != rURL) {
        this.router.navigate(['blog/' + rURL]);
      }
    }, err => {
      this.router.navigate(['pagenotfound']);
      console.log(err);
    });
  }
  // @HostListener('window:selecton', ['$event'])
  // mouseUp(event) {
  //   console.log(event)
  // }

}
