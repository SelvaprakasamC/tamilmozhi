import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/@core/services/pages/category.service';
import { Category } from 'src/app/@core/models/pages/category.model';
import { NestedTreeControl } from '@angular/cdk/tree';
import { MatTreeNestedDataSource } from '@angular/material/tree';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.scss']
})
export class SideNavComponent implements OnInit {
  categoryList;

  // Mat tree
  treeControl = new NestedTreeControl<Category>(node => node.subCategory);
  dataSource = new MatTreeNestedDataSource<Category>();

  constructor(
    private catgService: CategoryService
  ) { }

  ngOnInit() {
    this.getCategory();
  }
  // Mat tree
  hasChild = (_: number, node: Category) => !!node.subCategory && node.subCategory.length > 0;

  getCategory() {
    this.catgService.getCategory().subscribe(res => {
      this.categoryList = res;
      this.dataSource.data = this.categoryList;
      console.log(this.categoryList);
    });
  }

}
