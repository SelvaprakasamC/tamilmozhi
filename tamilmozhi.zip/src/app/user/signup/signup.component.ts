import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import { UserService } from 'src/app/@core/services/user/user.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  value;
  hide = true;
  message: boolean;
  errMessage: string;
  signUpForm: FormGroup;
  imageData: any;
  imageUrl: string;
  constructor(
    private userService: UserService,
    private _snackBar: MatSnackBar) { }

  ngOnInit() {
  }


  onSubmit(form: NgForm) {
    this.userService.postUser(form.value, this.imageData).subscribe(
      res => {
        this.message = true;
        this._snackBar.open('Saved Successfully!!', 'Okay', { duration: 3000 })
        setTimeout(() => {
          this.message = false;
        }, 4000);
        this.resetForm(form);
      },
      err => {
        if (err.status === 422) {
          this.errMessage = err.error.join('<br/>');
        } else {
          this._snackBar.open('Something Went Wrong!!', 'Okay', { duration: 5000 })
          this.errMessage = 'something went wrong';
        }
      }
    );

  }
  onFileSelect(event: Event) {
    const file = (event.target as HTMLInputElement).files[0];
    if (file.size < 512000) {
      this.errMessage = '';
      this.imageData = file;
      const allowedMimeTypes = ["image/png", "image/jpeg", "image/jpg"];
      if (file && allowedMimeTypes.includes(file.type)) {
        const reader = new FileReader();
        reader.onload = () => {
          this.imageUrl = reader.result as string;
        };
        reader.readAsDataURL(file);
      }
    } else {
      this.errMessage = 'File Size Max allowed 512kb';
    }
  }

  resetForm(form: NgForm) {
    this.userService.selectedUser = {
      fullName: '',
      email: '',
      password: '',
      userName: '',
      imagePath: 'https://cdn1.iconfinder.com/data/icons/mix-color-4/502/Untitled-1-512.png'
    };
    form.resetForm();
    this.errMessage = '';
    this.imageData = null;
  }

}

