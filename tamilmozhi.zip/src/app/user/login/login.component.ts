import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/@core/services/user/user.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  value;
  remember = true;
  hide = true;
  model = {
    email: '',
    password: ''
  };
  serverErrorMessages;
  constructor(
    private userService: UserService,
    private router: Router
  ) { }

  ngOnInit() {
    if (this.userService.isLoggedIn()) {
      this.router.navigate(['/admin']);
    }
  }

  onSubmit(form: NgForm) {
    this.userService.login(form.value).subscribe(
      res => {
        this.userService.setToken(JSON.stringify(res), this.remember);
        this.router.navigateByUrl('/admin');
      },
      err => {
        this.serverErrorMessages = err.error.message;
        this.router.navigateByUrl('/user/login');
      }
    );
  }

}
