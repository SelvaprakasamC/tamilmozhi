import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdminModule } from './admin/admin.module';
import { ViewModule } from './view/view.module';
import { LoginComponent } from './user/login/login.component';
import { SignupComponent } from './user/signup/signup.component';
import { UserComponent } from './user/user.component';
import { AuthGuard } from './@core/security/auth/auth.guard';
import { PagenotfoundComponent } from './theme/layout/pagenotfound/pagenotfound.component';

const routes: Routes = [
  {
    path: 'admin',
    loadChildren: () => AdminModule,
    canActivate: [AuthGuard]
  },
  {
    path: 'user', component: UserComponent,
    children: [
      { path: '', redirectTo: 'login', pathMatch: 'full' },
      { path: 'login', component: LoginComponent },
      { path: 'signup', component: SignupComponent },
    ]
  },
  {
    path: '',
    loadChildren: () => ViewModule
  }
  // {
  //   path: 'pagenotfound', component: PagenotfoundComponent
  // }, {
  //   path: '**', redirectTo: 'pagenotfound'
  // }


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
