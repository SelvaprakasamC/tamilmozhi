import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



const NB_MODULES = [
];

const COMPONENTS = [

];

@NgModule({
  imports: [CommonModule, ...NB_MODULES],
  exports: [CommonModule, ...COMPONENTS],
  declarations: [...COMPONENTS],
})
export class ThemeModule { }
