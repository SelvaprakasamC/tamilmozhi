export class User {
  fullName: string;
  userName: string;
  email: string;
  password: string;
  imagePath: string;
}
