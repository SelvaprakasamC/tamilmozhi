export class Category {
  _id: string;
  name: string;
  description: string;
  slug: string;
  type: number;
  mainParent?: string;
  subParent?: string;
  supParent?: string;
  author: any;
  subCategory?: Category[];
}
