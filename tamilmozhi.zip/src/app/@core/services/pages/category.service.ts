import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Category } from '../../models/pages/category.model';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  catg: Category[];

  readonly baseURL = environment.apiBaseUrl + '/catg/';

  constructor(private http: HttpClient) { }

  addCategory(catg: Category) {
    return this.http.post(this.baseURL, catg);
  }

  getCategory() {
    return this.http.get(this.baseURL);
  }

  updateCategory(catg: Category) {
    return this.http.put(this.baseURL + `${catg._id}`, catg);
  }

  deleteCategory(_id) {
    return this.http.delete(this.baseURL + `${_id}`);
  }
}
