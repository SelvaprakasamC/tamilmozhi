import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Page } from '../../models/pages/page.model';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PageService {

  selectPage: Page;
  page: Page[];

  readonly baseURL = environment.apiBaseUrl + '/page/';

  constructor(private http: HttpClient) { }

  addPage(page: Page) {
    return this.http.post(this.baseURL, page);
  }

  getPage(id: string) {
    return this.http.get(this.baseURL + `${id}`);
  }
  getPages() {
    return this.http.get(this.baseURL);
  }
  updatePage(page: Page) {
    return this.http.put(this.baseURL + `${page._id}`, page);
  }

  deletePage(_id: string) {
    return this.http.delete(this.baseURL + `${_id}`);
  }

  deleteimege(img: string) {
    return this.http.post(this.baseURL + 'image/', img);
  }
}
