import { Injectable } from '@angular/core';
import { User } from '../../models/user/user.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  selectedUser: User = {
    fullName: '',
    email: '',
    password: '',
    userName: '',
    imagePath: 'https://cdn1.iconfinder.com/data/icons/mix-color-4/502/Untitled-1-512.png'
  };
  private userSubject = new Subject<User>();
  public user$ = this.userSubject.asObservable();
  userDetails;
  noAuthHeader = { headers: new HttpHeaders({ NoAuth: 'True' }) };

  constructor(private http: HttpClient) { }

  // HTTP methods
  postUser(user: User, image: File) {
    console.log(user);
    const Type = image.type.split("/");
    const fileType = Type[1];
    let imageName = user.fullName.split(' ').join('_').toLowerCase() + '.' + fileType;
    const formData: FormData = new FormData();
    formData.append('fullName', user.fullName);
    formData.append('email', user.email);
    formData.append('password', user.password);
    formData.append('userName', user.userName);
    formData.append('image', image, imageName);

    return this.http.post(environment.apiBaseUrl + '/register', formData, this.noAuthHeader);
  }

  // postUser(user: User, image: File) {
  //   return this.http.post(environment.apiBaseUrl + '/register', user, this.noAuthHeader);
  // }

  login(authCredentials) {
    return this.http.post(environment.apiBaseUrl + '/authenticate', authCredentials, this.noAuthHeader);
  }

  getUserProfile() {
    return this.http.get(environment.apiBaseUrl + '/userProfile');
  }

  getUser(uName: string) {
    return this.http.get(environment.apiBaseUrl + '/user/' + uName);
  }

  updateUserProfile(user: User, image: File) {
    if (!image) {
      return this.http.put(environment.apiBaseUrl + '/updatePro/' + `${this.userDetails._id}`, user);
    }
    const formData: FormData = new FormData();
    formData.append('fullName', user.fullName);
    formData.append('email', user.email);
    formData.append('image', image, this.userDetails.imagePath);
    if (user.password) {
      formData.append('password', user.password);
    }
    return this.http.put(environment.apiBaseUrl + '/updatePro/' + `${this.userDetails._id}`, formData);
  }

  // Helper Methods

  setToken(user: any, remember: boolean) {
    if (remember) {
      localStorage.setItem('TamilMozhiUser', user);
    } else {
      sessionStorage.setItem('TamilMozhiUser', user);
    }
  }

  getToken() {
    if (localStorage.getItem('TamilMozhiUser') != null) {
      return localStorage.getItem('TamilMozhiUser');
    } else {
      return sessionStorage.getItem('TamilMozhiUser');
    }
  }


  // Sign out
  deleteToken() {
    if (localStorage.getItem('TamilMozhiUser') != null) {
      localStorage.removeItem('TamilMozhiUser');
    } else {
      sessionStorage.removeItem('TamilMozhiUser');
    }
    this.userSubject.next(null);
  }

  getUserPayload() {
    const user = JSON.parse(this.getToken());
    if (user) {
      const { token, ...rest } = user;
      this.userDetails = rest;
      this.userSubject.next(rest);
      const userPayload = atob(user.token.split('.')[1]);
      return JSON.parse(userPayload);
    } else {
      this.userDetails = null;
      this.userSubject.next(null);
      return null;
    }
  }

  isLoggedIn() {
    const userPayload = this.getUserPayload();
    if (userPayload) {
      return userPayload.exp > Date.now() / 1000;
    } else {
      return false;
    }
  }
}
